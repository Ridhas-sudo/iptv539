package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SherpaSubtitleManager
import kotlinx.coroutines.delay

/**
 * Bandeau de diagnostic des sous-titres vocaux (état du modèle, RAM, vitesse...).
 * Discret : il n'apparaît que QUELQUES SECONDES (6 s) à l'activation et à chaque CHANGEMENT d'état
 * (modèle prêt, échec, mauvais modèle, TV trop lente...), puis disparaît tout seul. Il ne reste plus
 * affiché en permanence par-dessus l'image.
 */
@Composable
fun VoiceDiagnosticsOverlay(enabled: Boolean) {
    if (!enabled) return
    val diag by SherpaSubtitleManager.diagnostics.collectAsState()
    val signature by SherpaSubtitleManager.diagSignature.collectAsState()
    var visible by remember { mutableStateOf(false) }

    LaunchedEffect(signature) {
        if (signature.isBlank()) {
            visible = false
        } else {
            visible = true
            delay(6000)
            visible = false
        }
    }

    AnimatedVisibility(
        visible = visible && diag.isNotBlank(),
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        Box(
            modifier = Modifier.fillMaxSize().padding(10.dp),
            contentAlignment = Alignment.TopStart
        ) {
            Text(
                text = diag,
                color = Color(0xFFFFE082),
                fontSize = 10.sp,
                maxLines = 6,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth(0.6f)
                    .background(Color(0x99000000), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 3.dp)
            )
        }
    }
}
