package com.example.debug

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import java.io.FileOutputStream
import androidx.core.content.FileProvider
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.Interceptor
import okhttp3.Response
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

enum class DebugLogLevel {
    LOG,
    INFO,
    WARN,
    ERROR,
    FUNCTION_CALL,
    STATE_CHANGE,
    API_CALL,
    CLICK
}

data class DebugLogEntry(
    val id: Long,
    val timestamp: String,
    val level: DebugLogLevel,
    val tag: String,
    val message: String
)

/**
 * Global Visual Debug System singleton
 */
object GlobalDebugSystem {
    private val counter = AtomicLong(0)
    private val maxLogs = 500
    private val dateFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())

    private var sharedPrefs: android.content.SharedPreferences? = null
    private var appContext: Context? = null

    private val _logs = MutableStateFlow<List<DebugLogEntry>>(emptyList())
    val logs: StateFlow<List<DebugLogEntry>> = _logs.asStateFlow()

    private val _hasLastCrashLog = MutableStateFlow(false)
    val hasLastCrashLog: StateFlow<Boolean> = _hasLastCrashLog.asStateFlow()

    private val _isDebugLoggingEnabled = MutableStateFlow(true)
    val isDebugLoggingEnabled: StateFlow<Boolean> = _isDebugLoggingEnabled.asStateFlow()

    private val _isConsoleVisible = MutableStateFlow(false)
    val isConsoleVisible: StateFlow<Boolean> = _isConsoleVisible.asStateFlow()

    private val _showFloatingButton = MutableStateFlow(true)
    val showFloatingButton: StateFlow<Boolean> = _showFloatingButton.asStateFlow()

    private val _isMinimized = MutableStateFlow(false)
    val isMinimized: StateFlow<Boolean> = _isMinimized.asStateFlow()

    private val mainHandler = Handler(Looper.getMainLooper())

    fun init(context: Context? = null) {
        if (context != null) {
            appContext = context.applicationContext
            try {
                sharedPrefs = context.getSharedPreferences("global_debug_prefs", Context.MODE_PRIVATE)
                val savedLogging = sharedPrefs?.getBoolean("debug_logging_enabled", true) ?: true
                val savedVisible = sharedPrefs?.getBoolean("debug_console_visible", false) ?: false
                val savedFab = sharedPrefs?.getBoolean("debug_fab_enabled", true) ?: true
                _isDebugLoggingEnabled.value = savedLogging
                _isConsoleVisible.value = savedVisible
                _showFloatingButton.value = savedFab
            } catch (e: Exception) {
                Log.w("GlobalDebugSystem", "Failed to load prefs: ${e.message}")
            }

            // Vérifier si un rapport de crash précédent est enregistré sur le disque
            try {
                val crashFile = File(context.filesDir, "last_crash_debug_log.txt")
                if (crashFile.exists() && crashFile.length() > 0) {
                    _hasLastCrashLog.value = true
                    Log.w("GlobalDebugSystem", "🚨 [CRASH LOG] Rapport de crash précédent présent : ${crashFile.absolutePath} (${crashFile.length()} bytes)")
                }
            } catch (e: Exception) { }
        }

        // Intercept uncaught exceptions on Android pour sauvegarder IMMÉDIATEMENT le debug log AVANT le plantage
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                saveCrashReportSync(thread, throwable)
            } catch (t: Throwable) {
                Log.e("GlobalDebugSystem", "Erreur sauvegarde crash log: ${t.message}", t)
            }
            defaultHandler?.uncaughtException(thread, throwable)
        }

        dlog("🚀 [GLOBAL_DEBUG_CONSOLE] Visual Debug Engine Initialized")
        logInfo("System", "Debug console attached. Monitoring: State Changes, Function Calls, API Requests (OkHttp/Fetch), Clicks & Errors.")
        if (_hasLastCrashLog.value) {
            logWarn("CrashDetector", "🚨 Un rapport de crash a été enregistré lors de la session précédente. Vous pouvez le consulter ou l'exporter.")
        }
    }

    /**
     * Sauvegarde synchrone et bloquante du debug log AVANT le crash effectif de l'application
     */
    fun saveCrashReportSync(thread: Thread, throwable: Throwable) {
        val timeStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault()).format(Date())
        val crashEntry = DebugLogEntry(
            id = counter.incrementAndGet(),
            timestamp = dateFormat.format(Date()),
            level = DebugLogLevel.ERROR,
            tag = "FATAL_CRASH",
            message = "💥 CRASH UNCAUGHT EXCEPTION dans le thread '${thread.name}': ${throwable.javaClass.name}: ${throwable.message}\n${Log.getStackTraceString(throwable)}"
        )

        val currentLogs = _logs.value + crashEntry
        val report = buildString {
            appendLine("==================================================")
            appendLine("🚨 CRASH REPORT - ENREGISTRÉ AVANT PLANTAGE 🚨")
            appendLine("Heure du crash : $timeStr")
            appendLine("Appareil : ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE}, API ${Build.VERSION.SDK_INT})")
            val runtime = Runtime.getRuntime()
            val usedMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
            val maxMb = runtime.maxMemory() / (1024 * 1024)
            appendLine("Mémoire JVM : ${usedMb}MB utilisés sur ${maxMb}MB max")
            appendLine("Thread : ${thread.name} (id: ${thread.id}, priority: ${thread.priority})")
            appendLine("Exception : ${throwable.javaClass.name}")
            appendLine("Message : ${throwable.message ?: "Aucun message"}")
            appendLine("--------------------------------------------------")
            appendLine("STACKTRACE COMPLÈTE DU CRASH :")
            appendLine(Log.getStackTraceString(throwable))
            appendLine("--------------------------------------------------")
            appendLine("JOURNAL DES DERNIERS LOGS (DEBUG CONSOLE - ${currentLogs.size} entrées) :")
            appendLine("==================================================")
            currentLogs.forEach { entry ->
                appendLine("${entry.timestamp} [${entry.tag}] [${entry.level}] ${entry.message}")
            }
            appendLine("==================================================")
            appendLine("FIN DU RAPPORT DE CRASH")
        }

        val ctx = appContext
        if (ctx != null) {
            try {
                // 1. Sauvegarde interne obligatoire dans context.filesDir/last_crash_debug_log.txt
                val crashFile = File(ctx.filesDir, "last_crash_debug_log.txt")
                FileOutputStream(crashFile, false).use { fos ->
                    fos.write(report.toByteArray(Charsets.UTF_8))
                    fos.flush()
                    fos.fd.sync()
                }

                // 2. Écraser également debug-log.txt pour qu'un export direct donne le crash log
                val normalFile = File(ctx.filesDir, "debug-log.txt")
                FileOutputStream(normalFile, false).use { fos ->
                    fos.write(report.toByteArray(Charsets.UTF_8))
                    fos.flush()
                    fos.fd.sync()
                }

                // 3. Essai d'écriture dans le stockage externe de l'application
                val extDir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                if (extDir != null) {
                    val extFile = File(extDir, "last_crash_debug_log.txt")
                    FileOutputStream(extFile, false).use { fos ->
                        fos.write(report.toByteArray(Charsets.UTF_8))
                        fos.flush()
                        fos.fd.sync()
                    }
                }
            } catch (e: Exception) {
                Log.e("GlobalDebugSystem", "Échec écriture crash report fichier: ${e.message}")
            }
        }
    }

    fun setDebugLoggingEnabled(enabled: Boolean) {
        _isDebugLoggingEnabled.value = enabled
        sharedPrefs?.edit()?.putBoolean("debug_logging_enabled", enabled)?.apply()
        if (enabled) {
            dlog("✅ Logging système activé")
        }
    }

    fun setConsoleVisible(visible: Boolean) {
        _isConsoleVisible.value = visible
        sharedPrefs?.edit()?.putBoolean("debug_console_visible", visible)?.apply()
    }

    fun toggleConsoleVisible() {
        setConsoleVisible(!_isConsoleVisible.value)
    }

    fun setShowFloatingButton(show: Boolean) {
        _showFloatingButton.value = show
        sharedPrefs?.edit()?.putBoolean("debug_fab_enabled", show)?.apply()
    }

    /**
     * Equivalent to window.dlog(msg)
     */
    @JvmStatic
    fun dlog(message: String) {
        addLog(DebugLogLevel.LOG, "dlog", message)
    }

    @JvmStatic
    fun logInfo(tag: String, message: String) {
        addLog(DebugLogLevel.INFO, tag, message)
    }

    @JvmStatic
    fun logWarn(tag: String, message: String) {
        addLog(DebugLogLevel.WARN, tag, message)
    }

    @JvmStatic
    fun logError(tag: String, message: String) {
        addLog(DebugLogLevel.ERROR, tag, message)
    }

    /**
     * Function call logging helper
     */
    @JvmStatic
    fun logFunctionCall(functionName: String, vararg args: Pair<String, Any?>) {
        val argsStr = if (args.isEmpty()) "()" else args.joinToString(prefix = "(", postfix = ")") { "${it.first}=${it.second}" }
        addLog(DebugLogLevel.FUNCTION_CALL, "fn_call", "⚡ $functionName$argsStr")
    }

    /**
     * State change logging helper
     */
    @JvmStatic
    fun logStateChange(stateName: String, oldValue: Any?, newValue: Any?) {
        addLog(DebugLogLevel.STATE_CHANGE, "state_change", "🔄 State [$stateName]: $oldValue ➔ $newValue")
    }

    /**
     * User click logging helper
     */
    @JvmStatic
    fun logClick(elementName: String, details: String = "") {
        val detailStr = if (details.isNotEmpty()) " [$details]" else ""
        addLog(DebugLogLevel.CLICK, "click", "👆 Click: $elementName$detailStr")
    }

    /**
     * API request logging helper
     */
    @JvmStatic
    fun logApiCall(method: String, url: String, status: Int? = null, durationMs: Long? = null, error: String? = null) {
        val timing = if (durationMs != null) " (${durationMs}ms)" else ""
        if (error != null) {
            addLog(DebugLogLevel.ERROR, "api_error", "🌐 ❌ [$method] $url ➔ $error$timing")
        } else if (status != null) {
            val icon = if (status in 200..299) "✅" else "⚠️"
            addLog(DebugLogLevel.API_CALL, "api_call", "🌐 $icon [$method] ($status) $url$timing")
        } else {
            addLog(DebugLogLevel.API_CALL, "api_call", "🌐 🛫 [$method] $url")
        }
    }

    private fun addLog(level: DebugLogLevel, tag: String, message: String) {
        if (!_isDebugLoggingEnabled.value && level != DebugLogLevel.ERROR) {
            return
        }
        val time = dateFormat.format(Date())
        val entry = DebugLogEntry(
            id = counter.incrementAndGet(),
            timestamp = time,
            level = level,
            tag = tag,
            message = message
        )
        
        // Logcat mirror
        when (level) {
            DebugLogLevel.ERROR -> Log.e(tag, message)
            DebugLogLevel.WARN -> Log.w(tag, message)
            DebugLogLevel.INFO -> Log.i(tag, message)
            else -> Log.d(tag, message)
        }

        // Thread-safe update
        val updateRunnable = Runnable {
            val current = _logs.value
            val updated = if (current.size >= maxLogs) {
                current.drop(current.size - maxLogs + 1) + entry
            } else {
                current + entry
            }
            _logs.value = updated
        }

        if (Looper.myLooper() == Looper.getMainLooper()) {
            updateRunnable.run()
        } else {
            mainHandler.post(updateRunnable)
        }
    }

    fun clearLogs() {
        _logs.value = emptyList()
        dlog("Console cleared.")
    }

    /**
     * Efface l'intégralité des logs de débogage et des rapports de crash enregistrés sur le disque et en mémoire
     */
    fun clearAllLogsAndCrashReports(context: Context) {
        try {
            _logs.value = emptyList()
            val crashFile = File(context.filesDir, "last_crash_debug_log.txt")
            if (crashFile.exists()) crashFile.delete()

            val normalFile = File(context.filesDir, "debug-log.txt")
            if (normalFile.exists()) normalFile.delete()

            val extDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            if (extDir != null) {
                File(extDir, "last_crash_debug_log.txt").takeIf { it.exists() }?.delete()
                File(extDir, "debug-log.txt").takeIf { it.exists() }?.delete()
                File(extDir, "ProIPTV_debug_crash_log.txt").takeIf { it.exists() }?.delete()
            }

            _hasLastCrashLog.value = false
            Toast.makeText(context, "🗑️ Tous les logs et rapports de crash ont été effacés !", Toast.LENGTH_SHORT).show()
            dlog("🗑️ Purge complète des logs et crash reports effectuée.")
        } catch (e: Exception) {
            logError("DebugSystem", "Erreur purge logs: ${e.message}")
        }
    }

    /**
     * Auto-nettoyage du stockage de l'application pour éviter les débordements de cache et les plantages
     */
    fun performAppStorageSelfClean(context: Context): String {
        var totalFreedBytes = 0L
        try {
            // 1. Nettoyage du cache interne (cacheDir)
            val cacheDir = context.cacheDir
            if (cacheDir != null && cacheDir.exists()) {
                cacheDir.listFiles()?.forEach { file ->
                    try {
                        val size = file.length()
                        if (file.deleteRecursively()) {
                            totalFreedBytes += size
                        }
                    } catch (t: Throwable) { }
                }
            }

            // 2. Nettoyage des fichiers temporaires dans filesDir (.tmp, logs temporaires)
            val filesDir = context.filesDir
            if (filesDir != null && filesDir.exists()) {
                filesDir.listFiles()?.forEach { file ->
                    if (file.name.endsWith(".tmp") || file.name.contains("temp", ignoreCase = true)) {
                        try {
                            val size = file.length()
                            if (file.delete()) {
                                totalFreedBytes += size
                            }
                        } catch (t: Throwable) { }
                    }
                }
            }

            // 3. Nettoyage du dossier Downloads externe privé
            val extDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            if (extDir != null && extDir.exists()) {
                extDir.listFiles()?.forEach { file ->
                    if (file.name.endsWith(".tmp")) {
                        try {
                            val size = file.length()
                            if (file.delete()) totalFreedBytes += size
                        } catch (t: Throwable) { }
                    }
                }
            }

            val freedMb = totalFreedBytes.toDouble() / (1024.0 * 1024.0)
            val formatted = if (freedMb < 0.1) String.format(Locale.US, "%.0f Ko", totalFreedBytes / 1024.0) else String.format(Locale.US, "%.1f Mo", freedMb)
            dlog("🧹 Auto-nettoyage stockage terminé : $formatted libérés.")
            return formatted
        } catch (e: Exception) {
            logError("StorageCleaner", "Erreur nettoyage: ${e.message}")
            return "0 Mo"
        }
    }

    /**
     * Exporte, télécharge et partage l'ensemble des logs de débogage ainsi que le dernier crash log
     */
    fun shareAllLogsAndCrashReport(context: Context) {
        try {
            val formattedLogs = getFormattedLogsText()
            val crashReport = getLastCrashReportText(context)
            val fullReport = buildString {
                appendLine("==================================================")
                appendLine("📱 PRO IPTV - RAPPORT GLOBAL DE DIAGNOSTIC & LOGS")
                appendLine("Date d'exportation : ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())}")
                appendLine("Appareil : ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE}, API ${Build.VERSION.SDK_INT})")
                val runtime = Runtime.getRuntime()
                val usedMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
                val maxMb = runtime.maxMemory() / (1024 * 1024)
                appendLine("Mémoire : ${usedMb}MB / ${maxMb}MB")
                appendLine("==================================================")
                if (!crashReport.isNullOrBlank()) {
                    appendLine("🚨 DERNIER RAPPORT DE CRASH ENREGISTRÉ :")
                    appendLine(crashReport)
                    appendLine("==================================================")
                }
                appendLine(formattedLogs)
            }

            val fileName = "ProIPTV_debug_crash_log.txt"
            val appFileDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
            val appFile = File(appFileDir, fileName)
            appFile.writeText(fullReport, Charsets.UTF_8)

            try {
                val contentUri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    appFile
                )
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "Pro IPTV - Logs & Crash Report")
                    putExtra(Intent.EXTRA_STREAM, contentUri)
                    putExtra(Intent.EXTRA_TEXT, fullReport)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
                }
                val chooser = Intent.createChooser(sendIntent, "Partager le rapport global de logs").apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(chooser)
            } catch (e: Exception) {
                Log.w("GlobalDebugSystem", "Chooser fallback: ${e.message}")
            }

            Toast.makeText(context, "💾 Rapport complet prêt pour le partage : ${appFile.name}", Toast.LENGTH_LONG).show()
            dlog("📤 Rapport complet exporté : ${appFile.absolutePath}")
        } catch (e: Exception) {
            logError("DebugSystem", "Erreur partage rapport: ${e.message}")
            Toast.makeText(context, "Erreur: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Partage spécifiquement le rapport de crash
     */
    fun shareLastCrashReport(context: Context) {
        try {
            val crashText = getLastCrashReportText(context)
            if (crashText.isNullOrBlank()) {
                Toast.makeText(context, "Aucun crash log enregistré à partager.", Toast.LENGTH_SHORT).show()
                return
            }
            val fileName = "last_crash_debug_log.txt"
            val appFileDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
            val appFile = File(appFileDir, fileName)
            appFile.writeText(crashText, Charsets.UTF_8)

            try {
                val contentUri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    appFile
                )
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "Pro IPTV - Rapport de Crash")
                    putExtra(Intent.EXTRA_STREAM, contentUri)
                    putExtra(Intent.EXTRA_TEXT, crashText)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
                }
                val chooser = Intent.createChooser(sendIntent, "Partager le Crash Log").apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(chooser)
            } catch (e: Exception) {
                Log.w("GlobalDebugSystem", "Share chooser fallback: ${e.message}")
            }
            Toast.makeText(context, "🚨 Rapport de Crash prêt pour le partage", Toast.LENGTH_LONG).show()
            dlog("📤 Partage du Crash Log déclenché.")
        } catch (e: Exception) {
            logError("CrashExporter", "Erreur partage crash log: ${e.message}")
            Toast.makeText(context, "Erreur: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun toggleMinimized() {
        _isMinimized.value = !_isMinimized.value
    }

    fun getFormattedLogsText(): String {
        val currentLogs = _logs.value
        val sb = StringBuilder()
        sb.appendLine("=== GLOBAL DEBUG CONSOLE LOGS (${currentLogs.size} entries) ===")
        sb.appendLine("Export Time: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault()).format(Date())}")
        sb.appendLine("==================================================")
        currentLogs.forEach { entry ->
            sb.appendLine("${entry.timestamp} [${entry.tag}] [${entry.level}] ${entry.message}")
        }
        sb.appendLine("==================================================")
        return sb.toString()
    }

    fun copyLogsToClipboard(context: Context) {
        try {
            val text = getFormattedLogsText()
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            val clip = ClipData.newPlainText("debug-log.txt", text)
            clipboard?.setPrimaryClip(clip)
            val count = _logs.value.size
            Toast.makeText(context, "✅ $count logs copied to clipboard!", Toast.LENGTH_SHORT).show()
            dlog("📋 Copied $count log entries to clipboard.")
        } catch (e: Exception) {
            logError("DebugConsole", "Failed to copy logs: ${e.message}")
            Toast.makeText(context, "Failed to copy: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun downloadLogsToFile(context: Context) {
        try {
            val text = getFormattedLogsText()
            val fileName = "debug-log.txt"
            var savedSuccessfully = false
            var fileSavedPath = ""

            // 1. Sur Android 10+ (API 29+), utiliser MediaStore Downloads pour respecter le Scoped Storage sans permission EACCES
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    val resolver = context.contentResolver
                    val contentValues = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                        put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                        put(MediaStore.MediaColumns.IS_PENDING, 1)
                    }
                    val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    val itemUri = resolver.insert(collection, contentValues)
                    if (itemUri != null) {
                        resolver.openOutputStream(itemUri)?.use { stream ->
                            stream.write(text.toByteArray(Charsets.UTF_8))
                            stream.flush()
                        }
                        val updateValues = ContentValues().apply {
                            put(MediaStore.MediaColumns.IS_PENDING, 0)
                        }
                        resolver.update(itemUri, updateValues, null, null)
                        savedSuccessfully = true
                        fileSavedPath = "Téléchargements / Downloads/debug-log.txt"
                    }
                } catch (e: Exception) {
                    Log.w("GlobalDebugSystem", "MediaStore save fallback: ${e.message}")
                }
            } else {
                // Sur les versions antérieures à Android 10
                try {
                    val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    if (downloadsDir != null) {
                        if (!downloadsDir.exists()) downloadsDir.mkdirs()
                        val outFile = java.io.File(downloadsDir, fileName)
                        outFile.writeText(text)
                        savedSuccessfully = true
                        fileSavedPath = outFile.absolutePath
                    }
                } catch (e: Exception) {
                    Log.w("GlobalDebugSystem", "Legacy public storage save fallback: ${e.message}")
                }
            }

            // 2. Toujours enregistrer également dans le stockage privé de l'application (garanti 100% sans permission)
            val appFileDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
            val appFile = java.io.File(appFileDir, fileName)
            appFile.writeText(text)
            if (fileSavedPath.isEmpty()) {
                fileSavedPath = appFile.absolutePath
                savedSuccessfully = true
            }

            // 3. Proposer le partage/ouverture via FileProvider (URI sécurisée content://)
            try {
                val contentUri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    appFile
                )
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "debug-log.txt")
                    putExtra(Intent.EXTRA_STREAM, contentUri)
                    putExtra(Intent.EXTRA_TEXT, text)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
                }
                val chooser = Intent.createChooser(sendIntent, "debug-log.txt (${_logs.value.size} logs)").apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(chooser)
            } catch (e: Exception) {
                // Si le chooser n'est pas supporté (ex: Android TV sans app de partage), ignorer silencieusement
                Log.d("GlobalDebugSystem", "Share chooser omitted: ${e.message}")
            }

            Toast.makeText(context, "💾 debug-log.txt enregistré (${_logs.value.size} logs)", Toast.LENGTH_LONG).show()
            dlog("💾 debug-log.txt enregistré avec succès : $fileSavedPath")
        } catch (e: Exception) {
            logError("DebugConsole", "Failed to download logs: ${e.message}")
            Toast.makeText(context, "Erreur sauvegarde logs: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Récupère le texte complet du dernier rapport de crash sauvegardé avant le plantage
     */
    fun getLastCrashReportText(context: Context): String? {
        return try {
            val crashFile = File(context.filesDir, "last_crash_debug_log.txt")
            if (crashFile.exists() && crashFile.length() > 0) {
                crashFile.readText(Charsets.UTF_8)
            } else null
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Copie le rapport de crash enregistré avant le plantage dans le presse-papier
     */
    fun copyLastCrashReportToClipboard(context: Context) {
        try {
            val crashText = getLastCrashReportText(context)
            if (crashText.isNullOrBlank()) {
                Toast.makeText(context, "Aucun rapport de crash enregistré", Toast.LENGTH_SHORT).show()
                return
            }
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            val clip = ClipData.newPlainText("last_crash_debug_log.txt", crashText)
            clipboard?.setPrimaryClip(clip)
            Toast.makeText(context, "🚨 Rapport de crash copié dans le presse-papier !", Toast.LENGTH_LONG).show()
            dlog("📋 Rapport de crash copié dans le presse-papier (${crashText.length} caractères)")
        } catch (e: Exception) {
            logError("CrashExporter", "Erreur copie crash log: ${e.message}")
            Toast.makeText(context, "Erreur: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Exporte et télécharge le fichier last_crash_debug_log.txt enregistré avant le plantage
     */
    fun downloadLastCrashReport(context: Context) {
        try {
            val crashText = getLastCrashReportText(context)
            if (crashText.isNullOrBlank()) {
                Toast.makeText(context, "Aucun rapport de crash enregistré", Toast.LENGTH_SHORT).show()
                return
            }
            val fileName = "last_crash_debug_log.txt"
            val appFileDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
            val appFile = File(appFileDir, fileName)
            appFile.writeText(crashText, Charsets.UTF_8)

            try {
                val contentUri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    appFile
                )
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "Rapport de Crash - last_crash_debug_log.txt")
                    putExtra(Intent.EXTRA_STREAM, contentUri)
                    putExtra(Intent.EXTRA_TEXT, crashText)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
                }
                val chooser = Intent.createChooser(sendIntent, "Exporter le rapport de crash").apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(chooser)
            } catch (e: Exception) {
                Log.d("GlobalDebugSystem", "Share chooser fallback: ${e.message}")
            }
            Toast.makeText(context, "💾 Rapport de crash enregistré : ${appFile.name}", Toast.LENGTH_LONG).show()
            dlog("💾 Rapport de crash exporté dans : ${appFile.absolutePath}")
        } catch (e: Exception) {
            logError("CrashExporter", "Erreur export crash log: ${e.message}")
            Toast.makeText(context, "Erreur: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun generateDiagnosticCrashReport(context: Context) {
        try {
            val fakeException = RuntimeException("Diagnostic & Simulation de Test Système Développeur")
            saveCrashReportSync(Thread.currentThread(), fakeException)
            _hasLastCrashLog.value = true
            Toast.makeText(context, "🔍 Rapport de Diagnostic Système généré avec succès", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            logError("Diagnostic", "Erreur génération diagnostic crash report: ${e.message}")
        }
    }

    fun clearLastCrashReport(context: Context) {
        try {
            val crashFile = File(context.filesDir, "last_crash_debug_log.txt")
            if (crashFile.exists()) {
                crashFile.delete()
            }
            _hasLastCrashLog.value = false
            Toast.makeText(context, "Rapport de crash effacé", Toast.LENGTH_SHORT).show()
            dlog("🗑️ Ancien rapport de crash supprimé.")
        } catch (e: Exception) { }
    }

    /**
     * OkHttp Interceptor for intercepting all API calls
     */
    fun createOkHttpInterceptor(): Interceptor {
        return Interceptor { chain ->
            val request = chain.request()
            val url = request.url.toString()
            val method = request.method
            val startNs = System.nanoTime()

            logApiCall(method, url)

            try {
                val response: Response = chain.proceed(request)
                val durationMs = (System.nanoTime() - startNs) / 1_000_000
                logApiCall(method, url, status = response.code, durationMs = durationMs)
                response
            } catch (e: Exception) {
                val durationMs = (System.nanoTime() - startNs) / 1_000_000
                logApiCall(method, url, error = e.message ?: e.javaClass.simpleName, durationMs = durationMs)
                throw e
            }
        }
    }
}

/**
 * Composable Visual Debug Console:
 * - Fixed black debug console at the bottom 40% of the screen
 * - Green monospace text
 * - Auto-scroll
 * - Clear button
 * - Close / Minimize button
 * - Green COPY button fixed at top-right
 * - DOWNLOAD button for saving debug-log.txt
 * - Tagged with id / testTag = "GLOBAL_DEBUG_CONSOLE"
 */
@Composable
fun GlobalDebugConsoleOverlay(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val logs by GlobalDebugSystem.logs.collectAsState()
    val isVisible by GlobalDebugSystem.isConsoleVisible.collectAsState()
    val isMinimized by GlobalDebugSystem.isMinimized.collectAsState()

    val listState = rememberLazyListState()

    // Auto-scroll to bottom whenever new logs arrive
    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    val showFab by GlobalDebugSystem.showFloatingButton.collectAsState()

    if (!isVisible) {
        if (showFab) {
            // Floating button to reopen console
            Box(
                modifier = modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.BottomEnd
            ) {
                FloatingActionButton(
                    onClick = { GlobalDebugSystem.setConsoleVisible(true) },
                    containerColor = Color(0xFF10141E),
                    contentColor = Color(0xFF00FF66),
                    shape = CircleShape,
                    modifier = Modifier
                        .size(44.dp)
                        .border(1.dp, Color(0xFF00FF66).copy(alpha = 0.5f), CircleShape)
                        .zIndex(9999f)
                ) {
                    Icon(
                        imageVector = Icons.Default.BugReport,
                        contentDescription = "Show Debug Console",
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
        return
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .zIndex(9999f),
        contentAlignment = Alignment.BottomCenter
    ) {
        AnimatedVisibility(
            visible = true,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .then(
                        if (isMinimized) Modifier.height(44.dp)
                        else Modifier.fillMaxHeight(0.40f) // Fixed bottom 40% of the screen
                    )
                    .background(Color(0xFF05080E).copy(alpha = 0.96f))
                    .border(
                        width = 1.5.dp,
                        color = Color(0xFF00FF66).copy(alpha = 0.6f),
                        shape = RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp)
                    )
                    .testTag("GLOBAL_DEBUG_CONSOLE")
            ) {
                // Header Bar with Controls (Fixed top bar of console)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                        .background(Color(0xFF0B101D))
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(Color(0xFF00FF66), CircleShape)
                        )
                        Text(
                            text = "DEBUG CONSOLE",
                            color = Color(0xFF00FF66),
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "(${logs.size})",
                            color = Color.Gray,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        )
                    }

                    // Top-Right Actions: Green COPY button, DOWNLOAD button, Clear, Minimize, Close
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val hasCrashLog by GlobalDebugSystem.hasLastCrashLog.collectAsState()
                        if (hasCrashLog) {
                            Button(
                                onClick = { GlobalDebugSystem.copyLastCrashReportToClipboard(context) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFFF2A4B),
                                    contentColor = Color.White
                                ),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .height(28.dp)
                                    .testTag("GLOBAL_DEBUG_CRASH_BUTTON")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.BugReport,
                                        contentDescription = "Rapport de crash",
                                        tint = Color.White,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = "CRASH",
                                        fontWeight = FontWeight.Black,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        color = Color.White
                                    )
                                }
                            }
                        }

                        // Fixed Green COPY Button at top-right
                        Button(
                            onClick = { GlobalDebugSystem.copyLogsToClipboard(context) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF00FF66),
                                contentColor = Color(0xFF05080E)
                            ),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .height(28.dp)
                                .testTag("GLOBAL_DEBUG_COPY_BUTTON")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Copy all logs",
                                    tint = Color(0xFF05080E),
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "COPY",
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = Color(0xFF05080E)
                                )
                            }
                        }

                        // DOWNLOAD Button for debug-log.txt
                        Button(
                            onClick = { GlobalDebugSystem.downloadLogsToFile(context) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF162235),
                                contentColor = Color(0xFF00E5FF)
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.5f)),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .height(28.dp)
                                .testTag("GLOBAL_DEBUG_DOWNLOAD_BUTTON")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Download,
                                    contentDescription = "Download debug-log.txt",
                                    tint = Color(0xFF00E5FF),
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "TXT",
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    color = Color(0xFF00E5FF)
                                )
                            }
                        }

                        // SHARE Button for debug logs + crash report
                        Button(
                            onClick = { GlobalDebugSystem.shareAllLogsAndCrashReport(context) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF0369A1),
                                contentColor = Color.White
                            ),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .height(28.dp)
                                .testTag("GLOBAL_DEBUG_SHARE_BUTTON")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "Partager logs",
                                    tint = Color.White,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = "SHARE",
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    color = Color.White
                                )
                            }
                        }

                        // Clear Button
                        IconButton(
                            onClick = { GlobalDebugSystem.clearAllLogsAndCrashReports(context) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = "Purger tous les logs",
                                tint = Color(0xFFFFB300),
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        // Minimize/Expand Button
                        IconButton(
                            onClick = { GlobalDebugSystem.toggleMinimized() },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = if (isMinimized) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = "Minimize / Expand",
                                tint = Color(0xFF9E9E9E),
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        // Close Button
                        IconButton(
                            onClick = { GlobalDebugSystem.setConsoleVisible(false) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close Console",
                                tint = Color(0xFFFF5252),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // Log entries list in Monospace Green & Custom Colors
                if (!isMinimized) {
                    if (logs.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Console is clear. Waiting for logs...",
                                color = Color(0xFF00FF66).copy(alpha = 0.5f),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp
                            )
                        }
                    } else {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            items(logs, key = { it.id }) { log ->
                                val textColor = when (log.level) {
                                    DebugLogLevel.ERROR -> Color(0xFFFF5252) // Red for uncaught / errors
                                    DebugLogLevel.WARN -> Color(0xFFFFD700)  // Gold for warnings
                                    DebugLogLevel.API_CALL -> Color(0xFF00E5FF) // Cyan for API / network calls
                                    DebugLogLevel.STATE_CHANGE -> Color(0xFFB388FF) // Purple for state changes
                                    DebugLogLevel.FUNCTION_CALL -> Color(0xFF69F0AE) // Bright mint for functions
                                    DebugLogLevel.CLICK -> Color(0xFFFF80AB) // Pink for user clicks
                                    DebugLogLevel.INFO -> Color(0xFF81D4FA) // Light blue
                                    DebugLogLevel.LOG -> Color(0xFF00FF66)  // Green standard console
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 1.dp)
                                ) {
                                    Text(
                                        text = "${log.timestamp} ",
                                        color = Color(0xFF757575),
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        lineHeight = 13.sp
                                    )
                                    Text(
                                        text = "[${log.tag}] ",
                                        color = Color(0xFF9E9E9E),
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        lineHeight = 13.sp
                                    )
                                    Text(
                                        text = log.message,
                                        color = textColor,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        lineHeight = 14.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
