# Proguard/R8 rules for optimizing and minifying Pro IPTV

# Keep all our local model classes from obfuscation so Gson serialization & Room work perfectly
-keep class com.example.data.** { *; }

# Retrofit & OkHttp
-dontwarn retrofit2.**
-keep class retrofit2.** { *; }
-keepattributes Signature, InnerClasses, EnclosingMethod

# Gson
-keepattributes *Annotation*
-dontwarn sun.misc.**
-keep class com.google.gson.** { *; }

# Room
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.**

# Media3 (ExoPlayer)
-dontwarn androidx.media3.**
-keep class androidx.media3.** { *; }

# AndroidX Compose
-keep class androidx.compose.** { *; }
-dontwarn androidx.compose.**

# Vosk Speech Recognition & JNA (Google TV / Android TV native support)
-keep class org.vosk.** { *; }
-dontwarn org.vosk.**
-keep class com.sun.jna.** { *; }
-dontwarn com.sun.jna.**
-keepclasseswithmembernames class * {
    native <methods>;
}


# Sherpa-ONNX : le code JNI lit les champs/constructeurs des classes Kotlin par leur NOM (GetFieldID).
# Sans cette règle, R8 les renomme en release et la reconnaissance vocale plante / ne charge aucun modèle.
-keep class com.k2fsa.sherpa.onnx.** { *; }
-dontwarn com.k2fsa.sherpa.onnx.**
